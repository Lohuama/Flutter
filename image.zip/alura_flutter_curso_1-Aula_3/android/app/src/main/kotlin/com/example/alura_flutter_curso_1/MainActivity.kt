package com.example.alura_flutter_curso_1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
